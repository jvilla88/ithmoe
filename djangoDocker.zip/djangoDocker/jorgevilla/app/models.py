from django.db import models
from django import forms
# Create your models here.


class Users(models.Model):
    email = models.EmailField(max_length=250)
    password = models.CharField(max_length=250)
    fullname = models.CharField(max_length=250)
    hack_pass = models.BooleanField(default=False)


class UserAddress(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE)
    postalcode = models.CharField(max_length=20)
    municipality = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    default_addr = models.BooleanField(blank=True, default=False)
