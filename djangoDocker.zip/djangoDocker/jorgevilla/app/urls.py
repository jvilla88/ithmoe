from django.urls import URLPattern
from . import views
from django.urls import path, include

urlpatterns = [
    path('new_user/', views.new_user, name="newuser"),
    path('', views.user_list, name='listusers'),
    path('user/<int:pk>', views.user_view, name='userview'),
    path('addaddress/<int:pk>', views.add_addr, name='addaddr'),
    path('removeaddress/<int:pk>', views.del_addr, name='deladdr'),
    path('update_user/<int:pk>', views.update_user, name='updateuser'),
    path('update_password/<int:pk>', views.update_password, name='updatepass'),
]
