from .forms import NewUser, NewAddress, UserForm, update_password_Form
from typing import List
from django.http.response import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.views.generic import ListView, DetailView

from app.models import UserAddress, Users, UserAddress
# Create your views here.


class ListUser(ListView):
    model = Users


def user_list(request, template_name='app/users_list.html'):
    user = Users.objects.all()
    data = {}
    data['object_list'] = user
    return render(request, template_name, data)


def user_view(request, pk, template_name='app/user_detail.html'):
    user = get_object_or_404(Users, pk=pk)
    user_address = []
    try:
        user_address = UserAddress.objects.filter(user=pk)
    except:
        pass
    return render(request, template_name, {'object': user, 'address': user_address})


def new_user(request, template_name='app/new_user.html'):
    if request.method == "POST":
        form = NewUser(request.POST)
        if form.is_valid():
            insert = Users(email=request.POST.get("email"),
                           fullname=request.POST.get("fullname"),
                           password=request.POST.get("password"),
                           hack_pass=0,

                           )
            insert.save()
            return redirect("listusers")
            # return HttpResponse(request.POST.get("email"))
    else:
        form = NewUser()
    return render(request, template_name, {'form': form})


def update_user(request, pk, template_name='app/new_user.html'):
    user = get_object_or_404(Users, pk=pk)
    form = UserForm(request.POST or None, instance=user)
    if form.is_valid():
        form.save()
        return redirect('listusers')
    return render(request, template_name, {'form': form, "update": True, "user": user})


def add_addr(request, pk, template_name='app/add_addr.html'):
    user = Users.objects.get(pk=pk)
    message = ""
    if request.method == "POST":
        form = NewAddress(request.POST)
        validate_address_qty = UserAddress.objects.filter(user_id=pk).count()
        if validate_address_qty < 3:
            if form.is_valid():
                if (request.POST.get("default_addr") == "on"):
                    booladdr = 1
                else:
                    booladdr = 0
                insert = UserAddress(
                    user_id=user.id,
                    postalcode=request.POST.get("postalcode"),
                    municipality=request.POST.get("municipality"),
                    state=request.POST.get("state"),
                    default_addr=booladdr,
                )
                insert.save()
                if booladdr == 1:
                    update_defautladdr(user.id, insert.id)
                return redirect("listusers")
                # return HttpResponse(validate_address_qty)
        else:
            message = "ERROR: USER HAS ALREADY 3 ADDRESSES  REGISTERED"
    else:
        form = NewAddress()
    return render(request, template_name, {"form": form, "user": user, "message": message})


def del_addr(request, pk, template_name='app/users_list.html'):
    data = []
    try:
        user = UserAddress.objects.filter(pk=pk).delete()
        return redirect("listusers")
    except:
        pass
    return render(request, template_name, data)


def update_defautladdr(user_id, id_addr):
    update_nondefault = UserAddress.objects.filter(
        user_id=user_id).update(default_addr=0)
    update_default = UserAddress.objects.filter(
        user_id=user_id, id=id_addr).update(default_addr=1)


def update_password(request, pk, template_name='app/update_passw.html'):
    user = Users.objects.get(pk=pk)
    if request.method == "POST":
        form = update_password_Form(request.POST)
        if form.is_valid():
            update_pass = Users.objects.filter(pk=pk).update(
                password=request.POST.get("password"), hack_pass=0)
            return redirect("listusers")
    else:
        form = update_password_Form()
    return render(request, template_name, {'form': form, "user": user})
