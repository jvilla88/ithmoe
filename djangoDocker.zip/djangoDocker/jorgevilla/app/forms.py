from django import forms
from app.models import Users
from django.forms import ModelForm


class UserForm(ModelForm):
    class Meta:
        model = Users
        fields = ['fullname', 'email', 'password', 'hack_pass']


class NewUser(forms.Form):
    fullname = forms.CharField(max_length=250, label="Full name")
    email = forms.EmailField(max_length=250, label="Email")
    password = forms.CharField(
        max_length=250, label="Password", widget=forms.PasswordInput)


class NewAddress(forms.Form):
    postalcode = forms.CharField(max_length=20, label="Postal Code")
    municipality = forms.CharField(max_length=100, label="Municpality")
    state = forms.CharField(max_length=100, label="State")
    default_addr = forms.BooleanField(required=False, label="Default Address")


class update_password_Form(forms.Form):
    password = forms.CharField(
        max_length=250, label="Password", widget=forms.PasswordInput)
